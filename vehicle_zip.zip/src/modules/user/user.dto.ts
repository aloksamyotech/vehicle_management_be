export class UserDto { 
    name : String
    type : String
}