import { Injectable } from '@nestjs/common';
import { PrismaService } from 'src/prisma/prisma.services';

@Injectable()
export class UserService {
  constructor(private prisma: PrismaService) {}

  async getUsers() {
    return  await this.prisma.user.findMany();
  }

  async createUser(email: string, name?: string) {
    return this.prisma.user.create({
      data: { email, name },
    });
  }
}
